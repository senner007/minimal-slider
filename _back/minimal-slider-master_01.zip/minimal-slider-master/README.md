# minimal-slider
minimal slider

### Install
- npm install -g parcel-bundler
- npm install jquery

### Run
- parcel index.html or npm run dev

### Fix
 - If parcel complains that functions are not functions you can:
 - 1. remove the cache dir
 - 2. type : npm install
 - 3. or repeat the install process

[Demo](http://www.nielshtg.dk/minimal-slider/)